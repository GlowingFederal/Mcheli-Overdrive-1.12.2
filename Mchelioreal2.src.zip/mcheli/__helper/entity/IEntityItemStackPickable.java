package mcheli.__helper.entity;

public interface IEntityItemStackPickable {}
