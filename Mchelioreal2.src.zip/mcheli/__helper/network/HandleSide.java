package mcheli.__helper.network;

import net.minecraftforge.fml.relauncher.Side;

public @interface HandleSide {
  Side[] value();
}
