/*    */ package mcheli.__helper.client.model;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.client.renderer.block.model.IBakedModel;
/*    */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*    */ import net.minecraft.client.renderer.block.model.ModelBlock;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.model.IModel;
/*    */ import net.minecraftforge.client.model.ItemLayerModel;
/*    */ import net.minecraftforge.client.model.PerspectiveMapWrapper;
/*    */ import net.minecraftforge.client.model.SimpleModelState;
/*    */ import net.minecraftforge.common.model.IModelState;
/*    */ import net.minecraftforge.common.model.TRSRTransformation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCH_WrapperItemLayerModel
/*    */   implements IModel
/*    */ {
/*    */   private ItemLayerModel model;
/*    */   private ModelBlock raw;
/*    */   
/*    */   public MCH_WrapperItemLayerModel(ModelBlock modelBlock) {
/* 37 */     this.raw = modelBlock;
/* 38 */     this.model = new ItemLayerModel(modelBlock);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ResourceLocation> getTextures() {
/* 44 */     return this.model.getTextures();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IModel retexture(ImmutableMap<String, String> textures) {
/* 50 */     return (IModel)this.model.retexture(textures);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IBakedModel bake(IModelState state, VertexFormat format, Function<ResourceLocation, TextureAtlasSprite> bakedTextureGetter) {
/* 57 */     ItemCameraTransforms transforms = this.raw.func_181682_g();
/* 58 */     Map<ItemCameraTransforms.TransformType, TRSRTransformation> tMap = Maps.newEnumMap(ItemCameraTransforms.TransformType.class);
/* 59 */     tMap.putAll((Map<? extends ItemCameraTransforms.TransformType, ? extends TRSRTransformation>)PerspectiveMapWrapper.getTransforms(transforms));
/* 60 */     tMap.putAll((Map<? extends ItemCameraTransforms.TransformType, ? extends TRSRTransformation>)PerspectiveMapWrapper.getTransforms(state));
/* 61 */     SimpleModelState simpleModelState = new SimpleModelState(ImmutableMap.copyOf(tMap), state.apply(Optional.empty()));
/* 62 */     return this.model.bake((IModelState)simpleModelState, format, bakedTextureGetter);
/*    */   }
/*    */ }


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\client\model\MCH_WrapperItemLayerModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */