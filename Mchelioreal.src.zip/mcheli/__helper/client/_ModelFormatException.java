/*    */ package mcheli.__helper.client;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _ModelFormatException
/*    */   extends RuntimeException
/*    */ {
/*    */   public _ModelFormatException() {}
/*    */   
/*    */   public _ModelFormatException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   
/*    */   public _ModelFormatException(String message, Throwable cause) {
/* 23 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public _ModelFormatException(Throwable cause) {
/* 28 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\client\_ModelFormatException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */