package mcheli.__helper.info;

import net.minecraft.item.Item;

public interface IItemContent {
  Item getItem();
}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\info\IItemContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */