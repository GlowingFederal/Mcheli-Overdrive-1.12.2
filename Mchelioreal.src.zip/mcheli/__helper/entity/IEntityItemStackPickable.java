package mcheli.__helper.entity;

public interface IEntityItemStackPickable {}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\entity\IEntityItemStackPickable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */