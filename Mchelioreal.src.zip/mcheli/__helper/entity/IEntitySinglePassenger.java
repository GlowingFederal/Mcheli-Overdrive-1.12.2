package mcheli.__helper.entity;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;

public interface IEntitySinglePassenger {
  @Nullable
  Entity getRiddenByEntity();
}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\entity\IEntitySinglePassenger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */