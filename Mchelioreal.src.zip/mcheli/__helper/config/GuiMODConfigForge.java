package mcheli.__helper.config;

public class GuiMODConfigForge {}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\config\GuiMODConfigForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */