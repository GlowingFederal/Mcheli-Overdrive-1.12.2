/*    */ package mcheli.__helper.debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 12023042301000021L;
/*    */   
/*    */   public DebugException(String msg) {
/* 15 */     super(msg);
/*    */   }
/*    */ 
/*    */   
/*    */   public DebugException(String msg, Throwable cause) {
/* 20 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\debug\DebugException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */