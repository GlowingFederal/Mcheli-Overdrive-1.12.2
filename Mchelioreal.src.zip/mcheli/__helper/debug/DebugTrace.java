/*    */ package mcheli.__helper.debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugTrace
/*    */ {
/*    */   public static void printOutTraceback() {
/* 13 */     (new RuntimeException()).printStackTrace(System.out);
/*    */   }
/*    */ }


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\debug\DebugTrace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */