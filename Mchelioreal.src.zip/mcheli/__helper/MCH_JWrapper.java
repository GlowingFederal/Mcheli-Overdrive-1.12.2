package mcheli.__helper;

public class MCH_JWrapper {}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\MCH_JWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */