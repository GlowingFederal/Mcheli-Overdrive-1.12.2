package mcheli.__helper.network;

import net.minecraftforge.fml.relauncher.Side;

public @interface HandleSide {
  Side[] value();
}


/* Location:              C:\Users\leo\Downloads\Mchelioreal\!\mcheli\__helper\network\HandleSide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */