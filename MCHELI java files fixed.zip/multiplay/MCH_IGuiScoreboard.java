package mcheli.multiplay;

public interface MCH_IGuiScoreboard {
  void switchScreen(MCH_GuiScoreboard_Base.SCREEN_ID paramSCREEN_ID);
}
