package mcheli.__helper.client;

public class _ModelFormatException extends RuntimeException {
  public _ModelFormatException() {}
  
  public _ModelFormatException(String message) {
    super(message);
  }
  
  public _ModelFormatException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public _ModelFormatException(Throwable cause) {
    super(cause);
  }
}
