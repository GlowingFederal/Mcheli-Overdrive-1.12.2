package mcheli.__helper.info;

import net.minecraft.item.Item;

public interface IItemContent {
  Item getItem();
}
