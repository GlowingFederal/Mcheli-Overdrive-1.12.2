package mcheli.gui;

import net.minecraft.client.Minecraft;

public class MCH_GuiListItem {
  public void mouseReleased(int x, int y) {}
  
  public boolean mousePressed(Minecraft mc, int x, int y) {
    return false;
  }
  
  public void draw(Minecraft mc, int mouseX, int mouseY, int posX, int posY, float partialTicks) {}
}
