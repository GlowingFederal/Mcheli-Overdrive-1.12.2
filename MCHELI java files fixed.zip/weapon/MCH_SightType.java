package mcheli.weapon;

public enum MCH_SightType {
  NONE, LOCK, ROCKET;
}
