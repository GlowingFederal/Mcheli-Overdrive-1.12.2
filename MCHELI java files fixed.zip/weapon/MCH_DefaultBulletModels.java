package mcheli.weapon;

public class MCH_DefaultBulletModels {
  public static MCH_BulletModel Bullet;
  
  public static MCH_BulletModel ATMissile;
  
  public static MCH_BulletModel ASMissile;
  
  public static MCH_BulletModel AAMissile;
  
  public static MCH_BulletModel Torpedo;
  
  public static MCH_BulletModel Bomb;
  
  public static MCH_BulletModel Rocket;
}
