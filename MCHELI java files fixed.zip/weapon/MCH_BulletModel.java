package mcheli.weapon;

import mcheli.__helper.client._IModelCustom;

public class MCH_BulletModel {
  public final String name;
  
  public final _IModelCustom model;
  
  public MCH_BulletModel(String n, _IModelCustom m) {
    this.name = n;
    this.model = m;
  }
}
