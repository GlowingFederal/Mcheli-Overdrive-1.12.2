package mcheli.lweapon;

import mcheli.wrapper.W_Item;

public class MCH_ItemLightWeaponBullet extends W_Item {
  public MCH_ItemLightWeaponBullet(int par1) {
    super(par1);
    setMaxStackSize(2);
    setMaxDamage(-1);
  }
}
