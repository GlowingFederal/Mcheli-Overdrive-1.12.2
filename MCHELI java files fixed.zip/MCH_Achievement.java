package mcheli;

import mcheli.__helper.MCH_CriteriaTriggers;

public class MCH_Achievement {
  public static void PreInit() {
    MCH_CriteriaTriggers.registerTriggers();
  }
}
