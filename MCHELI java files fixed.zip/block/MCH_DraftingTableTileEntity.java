package mcheli.block;

import net.minecraft.tileentity.TileEntity;

public class MCH_DraftingTableTileEntity extends TileEntity {}
