package mcheli.eval.eval.ref;

public interface Refactor {
  String getNewName(Object paramObject, String paramString);
  
  String getNewFuncName(Object paramObject, String paramString);
}
