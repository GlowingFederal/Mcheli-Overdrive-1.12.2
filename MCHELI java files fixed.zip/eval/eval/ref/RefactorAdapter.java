package mcheli.eval.eval.ref;

public class RefactorAdapter implements Refactor {
  public String getNewFuncName(Object target, String name) {
    return null;
  }
  
  public String getNewName(Object target, String name) {
    return null;
  }
}
